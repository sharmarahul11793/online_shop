<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class ShopControler extends Controller
{
    public function index(Request $request, $categorySlug=null, $subCategorySlug=null){
        $categorySelected ='';
        $subCategorySelected = '';
        $brandArray = [];



        $categories = Category::orderBy('id','ASC')->with('SubCategory')->where('status','0')->get();
        $brands = Brand::orderBy('id','ASC')->where('status','0')->get();

        $products = Product::where('status','0');

        //Apply Filters Here Started==================
        if(!empty($categorySlug)){
            $category = Category::where('slug',$categorySlug)->first();
            $products = $products->where('categoryId',$category->id);
            $categorySelected = $category->id;

        }

        if(!empty($subCategorySlug)){
            $subCategory = SubCategory::where('slug',$subCategorySlug)->first();
            $products = $products->where('subCategoryId',$subCategory->id);
            $subCategorySelected = $subCategory->id;
        }

        if(!empty($request->get('brand'))){
            $brandArray = explode(',',$request->get('brand'));
            $products  = $products->whereIn('brandId',$brandArray);
        }

        if($request->get('price_max') != '' && $request->get('price_min') !=''){
            if($request->get('price_max') == 1000){

                $products = $products->whereBetween('price',[intval($request->get('price_min')), 1000000]);
            }else{
            $products = $products->whereBetween('price',[intval($request->get('price_min')), intval($request->get('price_max'))]);
            }
        }

        if($request->get('sort') !=''){
            if($request->get('sort')=='latest'){

                $products = $products->orderBy('id','DESC');
            }elseif ($request->get('sort') == 'price_desc'){
                $products = $products->orderBy('price','DESC');
            }else {
                $products = $products->orderBy('price','ASC');
            }
        }else{
            $products = $products->orderBy('id','DESC');
        }

        // filter end==============================

        $products = $products->paginate(6);

        $data['categories'] = $categories;
        $data['products'] = $products;
        $data['brands'] = $brands;
        $data['categorySelected'] = $categorySelected;
        $data['subCategorySelected'] = $subCategorySelected;
        $data['brandArray'] = $brandArray;
        $data['priceMax'] = (intval($request->get('price_max')) == 0) ? '1000' : intval($request->get('price_max'));
        $data['priceMin'] = intval($request->get('price_min'));
        $data['sort'] = $request->get('sort');

        return view('front.shop',$data);


    }

    public function product($slug){
        // echo $slug;
        $products = Product::where('slug',$slug)->with('product_image')->first();
        // dd($products);



        if($products==Null){
            abort('404');
        }else{

            //Related product fetch
            $relatedProducts = [];
            if($products->related_products !=""){
                $productArray  = explode(',',$products->related_products);
                $relatedProducts = Product::whereIn('id',$productArray)->with('product_image')->get();
            }

            $data['products']= $products;
            $data['relatedProducts']= $relatedProducts;

            return view('front.product', $data);
        }
    }
}
