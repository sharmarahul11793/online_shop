<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class ProductSubCategory extends Controller
{
    public function index(Request $request)
    {
        if(!empty($request->category)){
            $category_id = $request->category;
            $subcategory = SubCategory::where('categoryId',$category_id)->get();
            return response()->json([
                'status' => true,
                'subcategory' => $subcategory
            ]);
        }else{
            return response()->json([
                'status' => true,
                'subcategory' => []
            ]);
        }

    }
}
