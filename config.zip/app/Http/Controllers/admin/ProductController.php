<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\SubCategory;
use App\Models\TempImage;
use Illuminate\Http\File as HttpFile;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $product  =Product::latest()->with('product_image');
            if($request->get('keyword')!=''){
                $product = $product->where('name','like','%'.$request->keyword.'%');
            }

        $product = $product->paginate(5);
        //dd($product);
        $data['product'] = $product;
        return view('admin.product.list',$data);
    }

    public function create()
    {
        $data = [];
        $category = Category::orderBy('name','asc')->get();
        $brand = Brand::orderBy('name','asc')->get();
        $data['category'] = $category;
        $data['brand'] = $brand;
        return view('admin.product.create',$data);
    }

    public function store(Request $request)
    {
        $rules =[
            'title' => 'required',
            'slug' => 'required|unique:products',
            'price' => 'required|numeric',
            'sku' => 'required|unique:products',
            'track_qty' => 'required|in:0,1',
            'category' => 'required|numeric',
            'isFeatured' => 'required|in:0,1',
        ];
        if(!empty($request->track_qty) && $request->track_qty == '1'){
            $rules['qty'] = 'required|numeric';
        }
        $validator = Validator::make($request->all(),$rules);
        if($validator->passes()){
            $product = new Product();
            $product->name = $request->title;
            $product->slug = $request->slug;
            $product->description = $request->description;
            $product->short_description = $request->short_description;
            $product->shipping_returns = $request->shipping_returns;
            $product->price = $request->price;
            $product->salePrice = $request->compare_price;
            $product->sku = $request->sku;
            $product->barcode = $request->barcode;
            $product->trackQty = $request->track_qty;
            $product->qty = $request->qty;
            $product->status = $request->status;
            $product->categoryId = $request->category;
            $product->subCategoryId = $request->sub_category;
            $product->brandId = $request->brandId;
            $product->isFeatured = $request->isFeatured;
            $product->related_products = (is_array($request->related_products)) ?  implode(',',$request->related_products) : $request->related_products;
            $product->save();

            //=============save images gallery=============
            if(!empty($request->image_id)){
            foreach($request->image_id as $tempImageId){

                $tempImageInfo = TempImage::find($tempImageId);
                $extArray  =explode('.',$tempImageInfo->name);//like 74732463667.jpg
                $extention = last($extArray);
                $productImage = new ProductImage();
                $productImage->productId = $product->id;
                $productImage->image = 1;
                $productImage->save();

                $imageName = $product->id.'-'.$productImage->id.'-'.time().'.'.$extention;
                $sourcePath = public_path() . '/temp/' . $tempImageInfo->name;
                $destinationPath = public_path() . '/uploads/product/' . $imageName;
                File::copy($sourcePath, $destinationPath);
                // $destinationPath = public_path() . '/uploads/product/';
                // File::move($tempImageInfo->name,$destinationPath.$imageName);

                $productImage->image = $imageName;
                $productImage->save();
                }
            }

            session()->flash('success','Product Created Successfully');

            return response()->json([
                'status' => true,
                'message' => 'Product Created Successfully'
            ]);
        }else{
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }

        //dd($request->all());
    }

    public function edit($id, Request $request){
        $product = Product::find($id);

        if(empty($product)){
            session()->flash('error','Product not found');
            return redirect()->route('products.index')->with('error','Product Not Found');
        }

        //Related product fetch
        $relatedProducts = [];
        if($product->related_products !=""){
            $productArray  = explode(',',$product->related_products);
            $relatedProducts = Product::whereIn('id',$productArray)->get();
        }

        //Product images fetch
        $productImage = ProductImage::where('productId',$product->id)->get();

        $subCategoryId = SubCategory::where('categoryId',$product->categoryId)->get();

        $data = [];
        $category = Category::orderBy('name','asc')->get();
        $brand = Brand::orderBy('name','asc')->get();
        $data['category'] = $category;
        $data['brand'] = $brand;
        $data['product'] = $product;
        $data['subCategoryId'] = $subCategoryId;
        $data['productImage'] = $productImage;
        $data['relatedProducts'] = $relatedProducts;
        return view('admin.product.edit',$data);
    }

    function update($id, Request $request){
        $product = Product::find($id);
        //dd($product);

        $rules =[
            'title' => 'required',
            'slug' => 'required|unique:products,slug,'.$product->id.',id',
            'price' => 'required|numeric',
            'sku' => 'required|unique:products,sku,'.$product->id.',id',
            'track_qty' => 'required|in:0,1',
            'category' => 'required|numeric',
            'isFeatured' => 'required|in:0,1',
        ];
        if(!empty($request->track_qty) && $request->track_qty == '1'){
            $rules['qty'] = 'required|numeric';
        }
        $validator = Validator::make($request->all(),$rules);
        if($validator->passes()){

            $product->name = $request->title;
            $product->slug = $request->slug;
            $product->description = $request->description;
            $product->short_description = $request->short_description;
            $product->shipping_returns = $request->shipping_returns;
            $product->price = $request->price;
            $product->salePrice = $request->compare_price;
            $product->sku = $request->sku;
            $product->barcode = $request->barcode;
            $product->trackQty = $request->track_qty;
            $product->qty = $request->qty;
            $product->status = $request->status;
            $product->categoryId = $request->category;
            $product->subCategoryId = $request->sub_category;
            $product->brandId = $request->brandId;
            $product->isFeatured = $request->isFeatured;
            $product->related_products = (is_array($request->related_products)) ?  implode(',',$request->related_products) : $request->related_products;
            $product->save();

            session()->flash('success','Product Updated Succeccfully');

            return response()->json([
                'status'  => true,
                'messages' => 'Product Updated'
            ]);
    }else{
        return response()->json([
            'status' => false,
            'message' => $validator->errors()
        ]);
    }
}

    function destroy($id, Request $request){
        $product  = Product::find($id);
        if(empty($product)){
            return response()->json([
                'status' =>false,
                'notFound' => true
            ]);
        }

        $productImage = ProductImage::where('productId',$id)->get();

        if(!empty($productImage)){
            foreach ($productImage as $getImage) {
                File::delete(public_path('uploads/product/'.$getImage->image));
            }

            ProductImage::where('productId',$id)->delete();
        }

        $product->delete();
        session()->flash('success','Product Delete Successfully');
        return response()->json([
            'status' =>true,
            'message' => 'Product Deleted'
        ]);
    }

    public function getRelatedProducts(Request $request){
        $tempProduct = [];
        if($request->term != ""){
            $products = Product::where('name', 'like','%'.$request->term.'%')->get();//http://localhost:8000/admin/getrelatedproducts?term=redmi&_type=query&q=redmi jb search krenge tb

            if($products != null){
                foreach($products as $product){
                    $tempProduct[] = array('id' => $product->id,'text' => $product->name);
                }
            }
        }

        // print_r($tempProduct);

        return response([
            'tags' => $tempProduct,
            'status' => true
        ]);
    }

}
