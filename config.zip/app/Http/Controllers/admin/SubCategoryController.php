<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    public function index(Request $request){
        $subCategory = SubCategory::select('sub_categories.*','categories.name as categoryName')
        ->join('categories','categories.id','sub_categories.categoryId')
        ->latest('sub_categories.id','asc');

        //for searching
        if (!empty($request->get('keyword'))) {
            $subCategory = $subCategory->where('sub_categories.name', 'like', '%' . $request->get('keyword') . '%');
            $subCategory = $subCategory->orWhere('categories.name', 'like', '%' . $request->get('keyword') . '%');
        }


        $subCategory = $subCategory->paginate(10);
        $data['subCategory'] = $subCategory;
        return view('admin.subCategory.list',$data);
    }

    public function create(){
        $category = Category::orderBy('name','asc')->get();
        $data['category'] = $category;
        return view('admin.subCategory.create',$data);
    }

    public function store(Request $request){
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required | unique:sub_categories',
            'status' => 'required',
            'categoryId' => 'required'
        ]);

        if($validator->passes()){
            $subCategory = new SubCategory();
            $subCategory->name= $request->name;
            $subCategory->slug= $request->slug;
            $subCategory->status= $request->status;
            $subCategory->categoryId= $request->categoryId;
            $subCategory->showHome= $request->showHome;
            $subCategory->save();

            session()->flash('success', 'Sub Category Created Successfully');

            return response([
                'status' => true,
                'message' => 'Sub Category Created Successfully'
            ]);

        }else{
            return response([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
    }

    public function edit($id){
        $subCategory = SubCategory::find($id);
        $category = Category::orderBy('name','asc')->get();
        $data['subCategory'] = $subCategory;
        $data['category'] = $category;
        return view('admin.subCategory.edit',$data);
    }

    public function update($id, Request $request)
    {
        $subCategory = SubCategory::find($id);


        if (empty($subCategory)) {
            return response()->json([
                'status' => false,
                'notFound' => true,
                'message' => 'Category not found'
            ]);
        }
        $validator  = Validator::make($request->all(), [
            'name' => 'required',
            'slug' => 'required|unique:sub_categories,slug,' . $subCategory->id . ',id',
        ]);

        if ($validator->passes()) {

            $subCategory->name = $request->name;
            $subCategory->slug = $request->slug;
            $subCategory->status = $request->status;
            $subCategory->categoryId = $request->categoryId;
            $subCategory->showHome= $request->showHome;
            $subCategory->save();


            session()->flash('success', 'Sub Category Update Successfully');

            return response()->json([
                'status' => true,
                'message' => 'Sub Category Updated Successfully'
            ]);
        } else {
            return response()->json([
                'status' => true,
                'errors' => $validator->errors(),
            ]);
        }
    }

    public function destroy($id, Request $request){
        $subCategory = SubCategory::find($id);
        $subCategory->delete();

        return response()->json([
            'status' => true,
            'message' => 'Sub Category Deleted Successfully'
        ]);
    }


}
