@if (Session::has('error'))
    <div class="col-md-12">
    <div class="alert alert-danger alert-dismissible">
        <i class="icon fa fa-ban"></i>!error {!! Session::get('error') !!}
    </div>
    </div>
@endif
@if (Session::has('success'))
    <div class="col-md-12">
    <div class="alert alert-success alert-dismissible">
        <i class="icon fa fa-check"></i>!Success {!! Session::get('success') !!}
    </div>
    </div>
@endif

@section('customjs1')
<script>
    $(document).ready(function(){
        setInterval(() => {
            $('.alert').hide();
        }, 1000);
    })
</script>
@endsection
