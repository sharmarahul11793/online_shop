<?php
    use App\Models\Category;

    function getCategory(){
        return Category::orderBy('name', 'asc')
        ->with('subCategory')
        ->orderBy('id','DESC')
        ->where('status','0')
        ->where('showHome','yes')
        ->get();
    }

?>
