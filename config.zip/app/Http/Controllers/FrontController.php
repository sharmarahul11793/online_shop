<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class FrontController extends Controller
{
    public function index() {
        $products = Product::where('isFeatured', '1')->where('status', '0')->orderBy('id','DESC')->get();
        $latestProducts = Product::orderBy('id', 'DESC')->where('status', '0')->take(8)->get();
        // Log the raw SQL query

        // Log::info(Product::where('isFeatured', '1')->where('status', '0')->toSql());
        // // Check if products are returned
        // Log::info($products);

        $data['featuredProducts'] = $products;
        $data['latestProducts'] = $latestProducts;
        return view('front.home', $data);
    }

}
