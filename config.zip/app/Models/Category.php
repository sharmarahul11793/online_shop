<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    public function subCategory(){//this is for a relations with category table
        return $this->hasMany(SubCategory::class, 'categoryId');
    }
}
