<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;

class HomeController extends Controller
{
    public function index()
    {
        //$admin=Auth::user();
        //echo "Welcome Home" . 'Click For' . '<a href="' . route('admin.logout') . '">Logout</a>';
        return view('admin.dashboard');
    }

    public function logout(Request $request)
    {
        Auth::guard('web')->logout();

        //
        return redirect()->route('admin.login');
    }
}
