<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid my-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Sub Category</h1>
                </div>
                <div class="col-sm-6 text-right">
                    <a href="<?php echo e(route('sub-categories.index')); ?>" class="btn btn-primary">Back</a>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="container-fluid">
            <form action="" method="POST" id="subCategoryformD" name="subCategoryform">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name">Category Name</label>
                                    <?php if(!empty($category)): ?>
                                        <select name="categoryId" id="categoryId" class="form-control select2">
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>"
                                                    <?php echo e($subCategory->categoryId == $data->id ? 'selected' : ''); ?>>
                                                    <?php echo e($data->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                    <p></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" id="name" value="<?php echo e($subCategory->name); ?>"
                                        class="form-control" placeholder="Name">
                                    <p></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email">Slug</label>
                                    <input type="text" name="slug" id="slug" value="<?php echo e($subCategory->slug); ?>"
                                        class="form-control" placeholder="Slug">
                                    <input type="hidden" name="image_id" id="image_id" />
                                    <p></p>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email">Status</label>
                                    <select class="form-control select2" name="status" id="status">
                                        <option <?php echo e($subCategory->status == 0 ? 'selected' : ''); ?> value="0">Active
                                        </option>
                                        <option <?php echo e($subCategory->status == 1 ? 'selected' : ''); ?> value="1">Inactive
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email">Show Home</label>
                                    <select class="form-control select2" name="showHome" id="showhome" >
                                        <option <?php echo e($subCategory->showHome =="yes" ? "selected" : ""); ?> value="yes">Yes</option>
                                        <option <?php echo e($subCategory->showHome =="no" ? "selected" : ""); ?> value="no">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pb-5 pt-3">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="<?php echo e(route('sub-categories.index')); ?>" class="btn btn-outline-dark ml-3">Cancel</a>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <script>
        $(function() {
            $('#subCategoryformD').submit(function(event) {
                //alert("hello");
                event.preventDefault();
                var element = $(this);
                $('button[type=submit]').prop('disabled', true);

                $.ajax({
                    url: '<?php echo e(route('sub-categories.update', $subCategory->id)); ?>',
                    type: 'post',
                    data: element.serializeArray(),
                    dataType: 'json',
                    success: function(response) {
                        $('button[type=submit]').prop('disabled', false);

                        window.location.href = "<?php echo e(route('sub-categories.index')); ?>"
                        var errors = response['errors'];
                        if (errors['name']) {
                            $('#name').addClass('is-invalid').siblings('p').addClass(
                                'invalid-feedback').html(errors['name']);
                        } else {
                            $('#name').removeClass('is-invalid').siblings('p').removeClass(
                                'invalid-feedback').html("");
                        }

                        if (errors['slug']) {
                            $('#slug').addClass('is-invalid').siblings('p').addClass(
                                'invalid-feedback').html(errors['slug']);
                        } else {
                            $('#slug').removeClass('is-invalid').siblings('p').removeClass(
                                'invalid-feedback').html("");
                        }

                    },
                    error: function(jqXHR, exception) {
                        console.log("Something went wrong");
                    }
                })
            });
        });


        $("#name").change(function() {
            element = $(this);
            $('button[type=submit]').prop('disabled', true);
            $.ajax({
                url: '<?php echo e(route('getSlug')); ?>',
                type: 'get',
                data: {
                    title: element.val()
                },
                dataType: 'json',
                success: function(response) {
                    $('button[type=submit]').prop('disabled', false);
                    if (response["status"] == true) {
                        $("#slug").val(response["slug"]);
                    }
                }
            });

        });

        Dropzone.autoDiscover = false;
        const dropzone = $('#image').dropzone({
            init: function() {
                this.on('addedfile', function(file) {
                    if (this.files.length > 1) {
                        this.removeFile(this.files[0]);
                    }
                });
            },
            url: "<?php echo e(route('temp-images.create')); ?>",
            maxFiles: 1,
            paramName: 'image',
            addRemoveLinks: true,
            acceptedFiles: "image/jpeg,image/png,image/gif",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(file, response) {
                $('#image_id').val(response.image_id);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\onlone_shop1\resources\views/admin/subCategory/edit.blade.php ENDPATH**/ ?>