<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use Illuminate\Auth\Events\Validated;
use Illuminate\Support\Facades\Validator;

class BrandController extends Controller
{

    public function index(Request $request){
        $brand = Brand::where('name', 'like', '%'.$request->search.'%')
        ->orWhere('slug', 'like', '%'.$request->search.'%')
        ->orderBy('id','desc')
        ->paginate(10);
        //$brand = Brand::paginate(10);

        //$brand = Brand::all();
        return view('admin.brands.list', compact('brand'));
    }

    public function create(){
        //$brand = Brand::all();
        return view('admin.brands.create');
    }

    public function store(Request $request){
        //dd($request->all());
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'slug' => 'required|unique:brands',

        ]);

        if($validator->passes()){
            $brand = new Brand();
            $brand->name = $request->name;
            $brand->slug = $request->slug;
            $brand->status = $request->status;
            $brand->save();

            session()->flash('success', 'Brand Created Successfully');
            //return redirect()->route('admin.brands.create');
            return response()->json([
                'status' => true,
                'success' => 'Brand Created Successfully',
                'brand' => $brand
            ]);
        }else{
            return response()->json([
                'status' => true,
                'errors' => $validator->errors()
            ]);
            //return redirect()->route('brands.create')->withErrors($validator)->withInput();
        }

    }

    public function edit($id){
        $brand = Brand::find($id);
        return view('admin.brands.edit', compact('brand'));
    }

    public function update(Request $request, $id){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'slug' => 'required|unique:brands,slug,'.$id,
        ]);

        if($validator->passes()){
            $brand = Brand::find($id);
            $brand->name = $request->name;
            $brand->slug = $request->slug;
            $brand->status = $request->status;
            $brand->save();

            session()->flash('success', 'Brand Updated Successfully');

            return response()->json([
                'status' => true,
                'message' => 'Brand Updated'
            ]);
            //return redirect()->route('brands.index');
        }else{
            return response()->json([
                'status' => true,
                'errors' => $validator->errors()
            ]);
        }
    }

    public function destroy($id){
        $brand = Brand::find($id);
        $brand->delete();

        session()->flash('success', 'Brand Deleted Successfully');

        return response()->json([
            'status' => true,
            'message' => 'Brand Deleted'
        ]);
        //return redirect()->route('brands.index');
    }

}
