<?php if(Session::has('error')): ?>
    <div class="col-md-12">
    <div class="alert alert-danger alert-dismissible">
        <i class="icon fa fa-ban"></i>!error <?php echo Session::get('error'); ?>

    </div>
    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="col-md-12">
    <div class="alert alert-success alert-dismissible">
        <i class="icon fa fa-check"></i>!Success <?php echo Session::get('success'); ?>

    </div>
    </div>
<?php endif; ?>

<?php $__env->startSection('customjs1'); ?>
<script>
    $(document).ready(function(){
        setInterval(() => {
            $('.alert').hide();
        }, 1000);
    })
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\xampp\htdocs\onlone_shop1\resources\views/admin/message.blade.php ENDPATH**/ ?>