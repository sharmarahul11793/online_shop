<?php $__env->startSection('content'); ?>

<section class="container">
    <div class="col-md-12 text-center py-5">
        <h1>Thank You!</h1>
        <p>Your Order Id is : <?php echo e($id); ?></p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\onlone_shop1\resources\views/front/thanks.blade.php ENDPATH**/ ?>