<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class ProductImageController extends Controller
{
    public function update(Request $request){

                $image = $request->image;
                $extention = $image->getClientOriginalExtension();
                $sourcePath = $image->getPathName();

                $productImage = new ProductImage();
                $productImage->productId = $request->productId;
                $productImage->image = 1;
                $productImage->save();

                $imageName = $request->productId.'-'.$productImage->id.'-'.time().'.'.$extention;
                $destinationPath = public_path() . '/uploads/product/' . $imageName;
                File::copy($sourcePath, $destinationPath);
                // $destinationPath = public_path() . '/uploads/product/';
                // File::move($tempImageInfo->name,$destinationPath.$imageName);

                $productImage->image = $imageName;
                $productImage->save();

                return response()->json([
                    'status' => true,
                    'image_id' =>$productImage->id,
                    'imagePath' => asset('uploads/product/'.$productImage->image),
                    'message' => 'Image saved successfully'
                ]);
    }

    public function destroy(Request $request){
        $productImage  =ProductImage::find($request->id);
        //delete image from folder
        File::delete(public_path('uploads/product/'.$productImage->image));

        $productImage->delete();

        return response()->json([
            'status' => true,
            'message' => 'Image deleted successfully'
        ]);
    }
}
