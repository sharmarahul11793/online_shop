<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Category;
use App\Models\TempImage;
use Illuminate\Support\Facades\File;
use Image;

class CategoriesController extends Controller
{
    public function index(Request $request)
    {
        $category = Category::latest();
        //for searching
        if (!empty($request->get('keyword'))) {
            $category = $category->where('name', 'like', '%' . $request->get('keyword') . '%');
        }

        $category = $category->paginate(7);
        //dd($category);
        //$data['category']  = $category;
        //return view('admin.category.list',$data);
        //OR----------------
        return view('admin.category.list', compact('category'));
    }
    public function create()
    {
        return view('admin.category.create');
    }
    public function store(Request $request)
    {
        $validator  = Validator::make($request->all(), [
            'name' => 'required',
            'slug' => 'required||unique:categories',
        ]);

        if ($validator->passes()) {
            $category = new Category();
            $category->name = $request->name;
            $category->slug = $request->slug;
            $category->status = $request->status;
            $category->showHome = $request->showHome;
            $category->save();

            //Image Upload Here
            if (!empty($request->image_id)) {
                $tempImage = TempImage::find($request->image_id);

                $extArray = explode('.', $tempImage->name);
                $ext  = last($extArray);
                $newImageName = $category->id . '.' . $ext;
                $sourcePath = public_path() . '/temp/' . $tempImage->name;
                $destinationPath = public_path() . '/uploads/category/' . $newImageName;
                File::copy($sourcePath, $destinationPath);

                //Generate Image Thumbnaill
                // $destinationPath = public_path().'/uploads/category/thumb/'.$newImageName;
                // $img=  Image::make($sourcePath);
                // $img->resize(450,500);
                // $img->save($destinationPath);

                $category->img = $newImageName;
                $category->save();
            }

            session()->flash('success', 'Category Added Successfully');

            return response()->json([
                'status' => true,
                'message' => 'Category Added Successfully'
            ]);
        } else {
            return response()->json([
                'status' => true,
                'errors' => $validator->errors(),
            ]);
        }
    }
    public function edit($categoryId, Request $request)
    {
        //echo  $categoryId;
        $category = Category::find($categoryId);
        if (empty($category)) {
            return redirect()->route('categories.index');
        }
        return view('admin.category.edit', compact('category'));
    }
    public function update($categoryId, Request $request)
    {
        $category = Category::find($categoryId);

        if (empty($category)) {
            return response()->json([
                'status' => false,
                'notFound' => true,
                'message' => 'Category not found'
            ]);
        }
        $validator  = Validator::make($request->all(), [
            'name' => 'required',
            'slug' => 'required|unique:categories,slug,' . $category->id . ',id',
        ]);

        if ($validator->passes()) {

            $category->name = $request->name;
            $category->slug = $request->slug;
            $category->status = $request->status;
            $category->showHome = $request->showHome;
            $category->save();

            $oldImg = $category->img;

            //Image Upload Here
            if (!empty($request->image_id)) {
                $tempImage = TempImage::find($request->image_id);

                $extArray = explode('.', $tempImage->name);
                $ext  = last($extArray);
                $newImageName = $category->id . '.' . $ext; //Or down
                //$newImageName = $category->id.'-'.time().'.'.$ext;
                $sourcePath = public_path() . '/temp/' . $tempImage->name;
                $destinationPath = public_path() . '/uploads/category/' . $newImageName;
                File::copy($sourcePath, $destinationPath);

                //Generate Image Thumbnaill
                // $destinationPath = public_path().'/uploads/category/thumb/'.$newImageName;
                // $img=  Image::make($sourcePath);
                // $img->resize(450,500);
                // $img->save($destinationPath);

                $category->img = $newImageName;
                $category->save();

                //Delete old image
                // File::delete(public_path().'uploads/category/'.$oldImg);
                // File::delete(public_path().'uploads/category/thumb/'.$oldImg);
            }
            session()->flash('success', 'Category Update Successfully');

            return response()->json([
                'status' => true,
                'message' => 'Category Updated Successfully'
            ]);
        } else {
            return response()->json([
                'status' => true,
                'errors' => $validator->errors(),
            ]);
        }
    }

    public function destroy($categoryId, Request $request)
    {
        $category = Category::find($categoryId);

        //Delete old image
        File::delete(public_path() . 'uploads/category/' . $category->img);
        File::delete(public_path() . 'uploads/category/thumb/' . $category->img);

        $category->delete();


        return response()->json([
            'status' => true,
            'message' => 'Data Delete Successfully'
        ]);
    }
}
