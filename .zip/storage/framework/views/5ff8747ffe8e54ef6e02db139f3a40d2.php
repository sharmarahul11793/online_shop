<?php $__env->startSection('content'); ?>
<section class="section-5 pt-3 pb-3 mb-3 bg-white">
    <div class="container">
        <div class="light-font">
            <ol class="breadcrumb primary-color mb-0">
                <li class="breadcrumb-item"><a class="white-text" href="#">Home</a></li>
                <li class="breadcrumb-item active">Shop</li>
            </ol>
        </div>
    </div>
</section>

<section class="section-6 pt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3 sidebar">
                <div class="sub-title">
                    <h2>Categories</h3>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="accordion accordion-flush" id="accordionExample">
                            <?php if($categories->isNotEmpty()): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="accordion-item">
                                <?php if($category->subCategory->isNotEmpty()): ?>
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne-<?php echo e($key); ?>" aria-expanded="false" aria-controls="collapseOne-<?php echo e($key); ?>">
                                        <?php echo e($category->name); ?>

                                    </button>
                                </h2>
                                <?php else: ?>
                                <a href="<?php echo e(route('front.shop',$category->slug)); ?>" class="nav-item nav-link <?php echo e(($categorySelected==$category->id ? 'text-primary' : '')); ?> "><?php echo e($category->name); ?></a>

                                <?php endif; ?>
                                <?php if($category->subCategory->isNotEmpty()): ?>

                                <div id="collapseOne-<?php echo e($key); ?>" class="accordion-collapse collapse <?php echo e(($categorySelected == $category->id ? 'show' : '')); ?>" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
                                    <div class="accordion-body">
                                        <div class="navbar-nav">
                                            <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <a href="<?php echo e(route('front.shop',[$category->slug,$subCategory->slug])); ?>" class="nav-item nav-link  <?php echo e(($subCategorySelected == $subCategory->id ? 'text-primary' : '')); ?> "><?php echo e($subCategory->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                        </div>
                    </div>
                </div>

                <div class="sub-title mt-5">
                    <h2>Brand</h3>
                </div>

                <div class="card">
                    <div class="card-body">
                        <?php if($brands->isNotEmpty()): ?>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check mb-2">
                            <input <?php echo e(in_array( $brand->id, $brandArray ) ? 'checked' : ''); ?> class="form-check-input brand-label" type="checkbox" name="brand[]" value="<?php echo e($brand->id); ?>" id="brand-<?php echo e($brand->id); ?>">
                            <label class="form-check-label" for="brand-<?php echo e($brand->id); ?>">
                                <?php echo e($brand->name); ?>

                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="sub-title mt-5">
                    <h2>Price</h3>
                </div>

                <div class="card">
                    <div class="card-body">
                        <input type="text" class="js-range-slider" name="my_range" value="" />
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row pb-3">
                    <div class="col-12 pb-1">
                        <div class="d-flex align-items-center justify-content-end mb-4">
                            <div class="ml-2">
                                

                                <select name="sort" id="sort" class="form-control">
                                    <option value="latest" <?php echo e(($sort =='latest' ? 'selected' : '')); ?>>Latest</option>
                                    <option value="price_desc" <?php echo e(($sort =='price_desc' ? 'selected' : '')); ?>> Hight to Low</option>
                                    <option value="price_asc" <?php echo e(($sort =='price_asc' ? 'selected' : '')); ?>> Low to High</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <?php if($products->isNotEmpty()): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $productImage =$product->product_image->first();
                    ?>
                    <div class="col-md-4">
                        <div class="card product-card">
                            <div class="product-image position-relative">
                                <a href="<?php echo e(route('front.product', $product->slug)); ?>" class="product-img">
                                    <?php if(!empty($productImage->image)): ?>

                                    <img class="card-img-top" src="<?php echo e(asset('uploads/product/'.$productImage->image)); ?>" style="height: 170px;" alt="">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('uploads/images/noimage.png')); ?>" alt="" height="50" style="height: 170px;" class="img-fluid">
                                    <?php endif; ?>
                                </a>
                                <a class="whishlist" href="222"><i class="far fa-heart"></i></a>

                                <div class="product-action">
                                    <a class="btn btn-dark" href="javascript:void(0)" onclick="addTocart('<?php echo e($product->id); ?>')">
                                        <i class="fa fa-shopping-cart"></i> Add To Cart
                                    </a>
                                </div>
                            </div>
                            <div class="card-body text-center mt-3">
                                <a class="h6 link" href="product.php"><?php echo e($product->name); ?></a>
                                <div class="price mt-2">
                                    <span class="h5"><strong>$<?php echo e($product->price); ?></strong></span>
                                    <?php if($product->salePrice > 0): ?>
                                    <span class="h6 text-underline"><del>$<?php echo e($product->salePrice); ?></del></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                    <div class="col-md-12 pt-5">
                        <?php echo e($products->withQueryString()->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('customJs'); ?>
    <script>
    rangeSlider=$(".js-range-slider").ionRangeSlider({
                type: "double",
                min: 0,
                max: 1000,
                step:10,
                skin:"round",
                max_postfix: "+",
                prefix: "$",
                from: <?php echo e(($priceMin)); ?>,
                to: <?php echo e(($priceMax)); ?>,
                // grid: true
                onFinish: function(){
                    apply_filter();
                }
    });

    var slider = $('.js-range-slider').data("ionRangeSlider")

        $('.brand-label').change( function(){
            apply_filter();
        });

        $('#sort').change( function(){
            apply_filter();
        })

        function apply_filter(){
            var brands = [];

            $(".brand-label").each(function(){
                if($(this).is(":checked") == true){
                    brands.push($(this).val());
                }
            });
            console.log(brands.toString());
            var url = '<?php echo e(url()->current()); ?>?';
            url += 'price_min='+slider.result.from +'&price_max='+slider.result.to;
            if(brands.length > 0){
                url  += '&brand='+brands;
            }

            url += '&sort='+$('#sort').val();
            window.location.href= url ;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\onlone_shop1\resources\views/front/shop.blade.php ENDPATH**/ ?>