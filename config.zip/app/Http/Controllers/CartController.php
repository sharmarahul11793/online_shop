<?php

namespace App\Http\Controllers;

use App\Models\Country;
use App\Models\CustomerAddress;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function addToCart(Request $request){
        $product = Product::with('product_image')->find($request->id);

        if($product==null){
            // return view('front.product');
            return response()->json([
                'status' => false,
                'message' => 'Product Not Found'
            ]);
        }

        if(Cart::count() > 0){
            // echo  "Product already Added";
            //Product found in cart
            //check if this product in the cart
            //Return as message that this product already added in the cart
            //if product not found in the cart , then add product in cart

            $cartContent = Cart::content();
            $productAlreadyExist =false;

            foreach($cartContent as $item){
                if($item->id == $product->id){
                    $productAlreadyExist = true;
                }
            }

            if($productAlreadyExist== false){

                Cart::add($product->id,$product->name,1,$product->price,
                ['productImage' => (!empty($product->product_image)) ? $product->product_image->first() : '']);
                $status = true;
                $message = '<strong>'.$product->name.'</strong> Product Added in cart ';
                session()->flash('success', $message);
            }else{
                $status  = false;
                $message = '<strong>'.$product->name.'</strong> Product Already Added in cart';
            }

        }else{
            // echo "Cart is empty so you  can add product now";
            Cart::add($product->id,$product->name,1,$product->price,
            ['productImage' => (!empty($product->product_image)) ? $product->product_image->first() : '']);
            $status = true;
            $message = '<strong>'.$product->name.'</strong> added in cart successfully';
            session()->flash('success', $message);
        }

        return response()->json([
            'status' => $status,
            'message' => $message
        ]);

    }

    public function cart(){
        $cartContent  = Cart::content();
        // dd(Cart::content());
        $data['cartContent'] = $cartContent;
        return view('front.cart', $data);
    }

    public function updateCart(Request $request){
        $rowId = $request->rowId;
        $qty = $request->qty;

        //for check qty availibility in stock
        $productInfo  =Cart::get($rowId);
        $product = Product::find($productInfo->id);
        if($product->trackQty == 1){
            if($product->qty >= $qty){
                Cart::update($rowId, $qty);
                $status = true;
                $message = 'Cart Updated Successfully';
                session()->flash('success', $message);
            }else{
                $message = 'Request qty ('.$qty.') not available in stock';
                $status = false;
                session()->flash('error', $message);
            }
        }else{
            Cart::update($rowId, $qty);
                $status = true;
                $message = 'Cart Updated Successfully';
                session()->flash('success', $message);
        }



        return response()->json([
            'status' => true,
            'message' => $message
        ]);
    }

    function deleteItem(Request $request){
        $productInfo  =Cart::get($request->rowId);

        if($productInfo==null){
            $errorMessage = 'Item not found in cart';
            session()->flash('error', $errorMessage);
            return response()->json([
                'status' =>false,
                'message' => $errorMessage
            ]);
        }

        Cart::remove($request->rowId);
        $successMessage = 'Item Deleted from Cart successfully';
        session()->flash('success', $successMessage);
        return response()->json([
            'status' =>true,
            'message' => $successMessage
        ]);
    }

    public function checkout(){

        //-------if cart is empty then redorect to cart page-------
        if(Cart::count()==0){
            return redirect()->route('front.cart');
        }
        //------if user not logged in then redirect login page
        if(Auth::check()==false){
            //----for curent url store and after login redirect it
            if(!session()->has('url.intended')){
                session(['url.intended'=> url()->current()]);
            }

            return redirect()->route('front.login');
        }

        // $customerAddress = CustomerAddress::find(Auth::user()->id);
        $customerAddress = CustomerAddress::where('user_id',Auth::user()->id)->first();
        session()->forget('url.intended');

        $countries = Country::orderBy('name','ASC')->get();

        return view('front.checkout',[
            'countries' => $countries,
            'customerAddress'=>$customerAddress
        ]);
    }

    public function proccessCheckout(Request $request){
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|min:3',
            'last_name' => 'required',
            'email' => 'required|email',
            'country_id' => 'required',
            'address' => 'required|min:20',
            'city' => 'required',
            'state' => 'required',
            'zip' => 'required',
            'mobile' => 'required'
        ]);

        if($validator->fails()){
            return response()->json([
                'message' => 'Please Fix the errors',
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }

        //-------------Save user address------------
        $user   =Auth::user();
        CustomerAddress::updateOrCreate(
            ['user_id' => $user->id],
            [
                'user_id' => $user->id,
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'email' => $request->email,
                'mobile' => $request->mobile,
                'country_id' => $request->country_id,
                'address' => $request->address,
                'appartment' => $request->appartment,
                'city' => $request->city,
                'state' => $request->state,
                'zip' => $request->zip
            ]
        );

        //---------------Order record store in order table------------

        if($request->payment_method == 'cod'){
            $shipping = 0;
            $discount =0 ;
            //Cart::subtotal($decimals, $decimalSeperator, $thousandSeperator);
            $subTotal = Cart::subtotal('2','.','');
            $grandTotal = $shipping+$subTotal;

            $order = new Order();
            $order->user_id = $user->id ;
            $order->subtotal = $subTotal;
            $order->shipping = $shipping;
            $order->grand_total = $grandTotal;
            $order->first_name = $request->first_name;
            $order->last_name = $request->last_name;
            $order->email = $request->email;
            $order->mobile = $request->mobile;
            $order->country_id = $request->country_id;
            $order->address = $request->address;
            $order->appartment = $request->appartment;
            $order->city =$request->city;
            $order->state = $request->state;
            $order->zip = $request->zip;
            $order->notes = $request->notes;
            $order->save();

            //------------order items store in orderitems table-------
            foreach(Cart::content() as $item){
                $orderItem =new OrderItem();
                $orderItem->order_id = $order->id;
                $orderItem->product_id = $item->id;
                $orderItem->name = $item->name;
                $orderItem->qty = $item->qty;
                $orderItem->price = $item->price;
                $orderItem->total = $item->price*$item->qty;
                $orderItem->save();
            }

            session()->flash('You have successfully order placed');
            Cart::destroy();

            return response()->json([
                'status' => true,
                'message' => 'You have order successfully saved',
                'orderId' => $order->id
            ]);

        }else{

        }
    }

    public function thankyou($id){
        return view('front.thanks',[
            'id' => $id
        ]);
    }

}
